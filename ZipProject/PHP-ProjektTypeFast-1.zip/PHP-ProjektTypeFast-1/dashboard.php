<?php
// ============================================================================
// DASHBOARD REDIRECT - Redirect to pages/dashboard.php
// ============================================================================
// This file allows users to access dashboard.php directly from root URL
// Usage: http://localhost/typefast/dashboard.php

header('Location: pages/dashboard.php');
exit;
?>
