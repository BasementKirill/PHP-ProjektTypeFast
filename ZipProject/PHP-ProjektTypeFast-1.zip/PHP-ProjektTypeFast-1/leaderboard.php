<?php
// ============================================================================
// LEADERBOARD REDIRECT - Redirect to pages/leaderboard.php
// ============================================================================
// This file allows users to access leaderboard.php directly from root URL
// Usage: http://localhost/typefast/leaderboard.php

header('Location: pages/leaderboard.php');
exit;
?>
