<?php
// Database configuration for XAMPP
return [
    'host' => 'localhost',
    'dbname' => 'typefast',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];
?>
