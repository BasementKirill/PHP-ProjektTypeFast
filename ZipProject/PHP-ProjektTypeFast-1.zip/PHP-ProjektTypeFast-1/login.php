<?php
// Redirect to login page - this file makes it easier to access login.php
header('Location: pages/login.php');
exit;
?>
