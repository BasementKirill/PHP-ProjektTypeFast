<?php
// ============================================================================
// LOGOUT REDIRECT - Redirect to pages/logout.php
// ============================================================================
// This file allows users to access logout.php directly from root URL
// Usage: http://localhost/typefast/logout.php

header('Location: pages/logout.php');
exit;
?>
