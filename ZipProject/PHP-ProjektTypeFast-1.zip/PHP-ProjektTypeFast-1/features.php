<?php
// ============================================================================
// FEATURES REDIRECT - Redirect to pages/features.php
// ============================================================================
// This file allows users to access features.php directly from root URL
// Usage: http://localhost/typefast/features.php

header('Location: pages/features.php');
exit;
?>
